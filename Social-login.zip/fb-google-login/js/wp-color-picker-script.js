jQuery(document).ready(function(){
    jQuery('.color-picker').wpColorPicker();
});