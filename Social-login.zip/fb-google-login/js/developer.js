jQuery(document).ready(function(){
    jQuery( "body" ).delegate( "#fbLogin", "click", function() {
        fbLogin();
    });
});

/*============== Facebook Login code =================*/

window.fbAsyncInit = function() {
    // FB JavaScript SDK configuration and setup
    FB.init({
      appId      : jQueryOBJ.fb_app_id, // FB App ID
      cookie     : true,  // enable cookies to allow the server to access the session
      xfbml      : true,  // parse social plugins on this page
      version    : 'v2.8' // use graph api version 2.8
    });
};
// Load the JavaScript SDK asynchronously
(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

// Facebook login with JavaScript SDK
function fbLogin() {
    FB.login(function (response) {
        if (response.authResponse) {
            getFbUserData();
        }
    }, {scope: 'email'});
}
function getFbUserData(){
    FB.api('/me', {locale: 'en_US', fields: 'id,first_name,last_name,email,link,gender,locale,picture'},
    function (response) {
        saveUserData(response);
    });
}

/*============== End Facebook Login code =================*/

function saveUserData(userData){
    jQuery.post(jQueryOBJ.ajaxurl, {
        'action':'user_data',
        userData: userData,
    }, function(data){ 
        if(data == 'ok'){
            window.location = jQueryOBJ.adminUrl;
        }else{
            alert('error!');
        }
    });
}

/*============== Google Login code =================*/

jQuery(document).ready(function(){
    var googleUser = {};
    gapi.load('auth2', function(){
      // Retrieve the singleton for the GoogleAuth library and set up the client.
      auth2 = gapi.auth2.init({
        client_id: jQueryOBJ.google_client_id,
        cookiepolicy: 'single_host_origin',
        scope: 'profile email'
      });
      attachSignin(jQuery("#G_Login")[0]);
    });
});
function attachSignin(element) {
    auth2.attachClickHandler(element, {},
    function(googleUser) {
        gapi.client.load('plus', 'v1', function () {
                var request = gapi.client.plus.people.get({
                'userId': 'me'
            });
            request.execute(function (resp) {
                saveUserData(resp);
            });
        });
    }, function(error) {
        // alert('error!');
    });
}

/*============== End Google Login code =================*/

