<?php
/*
Plugin Name: Facebook Google Login
Plugin URI: #
Description: This is Social Login plugin
Version: 1.0
Author: Vinay Shah
Author URI: #
Copyright: Tops Technologies
*/


/*
Add Scripts for plugin
*/
function jquery_min_add_wp_login_page(){
    wp_enqueue_script( 'jquery-min-js',  plugin_dir_url(__FILE__) . 'js/jquery-1.12.4.min.js',array(),'', true );
}
add_action( 'login_enqueue_scripts', 'jquery_min_add_wp_login_page', 1);
function social_login_scripts() {

    wp_enqueue_style( 'developer-css', plugin_dir_url(__FILE__) . 'css/developer.css', array());
    
    wp_enqueue_script( 'google-api', 'https://apis.google.com/js/api:client.js',array(),'', true );

    wp_enqueue_script( 'developer-js',  plugin_dir_url(__FILE__) . 'js/developer.js',array(),'', true );

    wp_localize_script( 'developer-js', 'jQueryOBJ',array('ajaxurl' => admin_url('admin-ajax.php'),'home_url'=>site_url(),'is_user_logged_in' => is_user_logged_in(),'fb_app_id'=> get_option('fb_app_id'),'google_client_id'=> get_option('google_client_id'),'adminUrl' => admin_url()));

    wp_register_style('theme-dynamic-styles', plugin_dir_url(__FILE__) . 'css/custom.css');

	$output = ".socialLogin .fb_Class{color: ".get_option('fb_text_color').";background:".get_option('fb_bg_color')."}";
	$output .= ".socialLogin .fb_Class:hover{color: ".get_option('fb_bg_color').";background:".get_option('fb_text_color')."}";
	$output .= ".socialLogin .goo_Class{color: ".get_option('goo_text_color').";background:".get_option('goo_bg_color')."}";
	$output .= ".socialLogin .goo_Class:hover{color: ".get_option('goo_bg_color').";background:".get_option('goo_text_color')."}";
	
	wp_add_inline_style('theme-dynamic-styles', $output);  
	wp_enqueue_style('theme-dynamic-styles');
}
add_action( 'wp_enqueue_scripts', 'social_login_scripts' );
add_action( 'login_enqueue_scripts', 'social_login_scripts', 1);


/*
Add option page in admin bar inside settings
*/
add_action( 'admin_menu', 'my_plugin_menu' );

function my_plugin_menu() {
	add_options_page( 'Social Login', 'Social Login', 'manage_options', 'social-login', 'my_plugin_options');
}
function my_plugin_options() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	?>
	<div class="wrap">
	<div class="socialDiv">
        <h2>Social Login</h2><hr/>
        <form method="post" action="options.php">
            <?php settings_fields( 'social-settings-group' ); ?>
            <p><strong>Note : </strong><span class="italic">Leave empty ( Facebook App id, Google Client id ) for disable it.</span></p>
            <p><strong>Facebook App id : </strong>
                <input type="text" name="fb_app_id" value="<?php echo get_option('fb_app_id'); ?>" />
            </p>
            <p><strong>Google Client id : </strong>
                <input type="text" name="google_client_id" value="<?php echo get_option('google_client_id'); ?>" />
            </p>
            <p class="italic">Use <input type="text" size="5" value="[social-login]" readonly="" /> Shortcode for display in template file or editor.
            </p>
            <table>
            	<caption>Facebook Button</caption>
            	<tr>
					<td><strong>Text Color : </strong></td>
					<td><input value="<?php echo !empty(get_option('fb_text_color')) ? get_option('fb_text_color') : '#3b5998' ?>" class="color-picker wp-color-picker" data-default-color="#3b5998" size="8" name="fb_text_color" /></td>
				</tr>
				<tr>
					<td><strong>Background Color : </strong></td>
					<td><input value="<?php echo !empty(get_option('fb_bg_color')) ? get_option('fb_bg_color') : '#dddddd' ?>" class="color-picker wp-color-picker" data-default-color="#dddddd" size="8" name="fb_bg_color" /></td>
				</tr>
			</table>
			<table>
            	<caption>Google+ Button</caption>
            	<tr>
					<td><strong>Text Color : </strong></td>
					<td><input value="<?php echo !empty(get_option('goo_text_color')) ? get_option('goo_text_color') : '#C03B30' ?>" class="color-picker wp-color-picker" data-default-color="#C03B30" size="8" name="goo_text_color" /></td>
				</tr>
				<tr>
					<td><strong>Background Color : </strong></td>
					<td><input value="<?php echo !empty(get_option('goo_bg_color')) ? get_option('goo_bg_color') : '#dddddd' ?>" class="color-picker wp-color-picker" data-default-color="#dddddd" size="8" name="goo_bg_color" /></td>
				</tr>
			</table>
          	<?php submit_button(); ?>
        </form>
    </div>
    </div>
	<?php
}

add_action( 'admin_init', 'register_mysettings' );

function register_mysettings() { 
  register_setting( 'social-settings-group', 'fb_app_id' );
  register_setting( 'social-settings-group', 'google_client_id' );
  register_setting( 'social-settings-group', 'fb_text_color' );
  register_setting( 'social-settings-group', 'fb_bg_color' );
  register_setting( 'social-settings-group', 'goo_text_color' );
  register_setting( 'social-settings-group', 'goo_bg_color' );
}

/*
Create shortcode for button
*/
function add_social_buttons(){
    if(!is_user_logged_in()){
    	$html = '<div class="socialLogin">';
        $fb = get_option('fb_app_id');
        $google = get_option('google_client_id');
            if(!empty($fb)){
                $html .= '<a id="fbLogin" class="fb_Class"><i class="fa fa-facebook-official fa-2x"></i><span> Login with Facebook</span></a>';
            }
            if(!empty($google)){
                $html .= '<a id="G_Login" class="goo_Class"><i class="fa fa-google-plus fa-2x"></i><span> Login with Google</span></a>';
            }
		$html .= '</div>';
    	echo $html;
    }    
}
add_shortcode('social-login', 'add_social_buttons');
add_action( 'login_form','add_social_buttons' );


/*
Social Login and registration function
*/

add_action( 'wp_ajax_user_data', 'social_login' );
add_action( 'wp_ajax_nopriv_user_data', 'social_login' );

function social_login(){
    $userData = $_POST['userData'];

    if($userData['isPlusUser']){
        $userEmail = $userData['emails'][0]['value'];
        $firstName = $userData['name']['givenName'];
        $lastName = $userData['name']['familyName'];
        $userLogin = $firstName.$lastName;
    }else{
        $userEmail = $userData['email'];
        $firstName = $userData['first_name'];
        $lastName = $userData['last_name'];
        $userLogin = $firstName.$lastName;
    }
    
    $new_user_data = array(
        'user_login' => $userLogin,
        'user_pass'  => '',
        'user_email' => $userEmail,
        'nickname'   => $firstName,
        'first_name' => $firstName,
        'last_name'  => $lastName,
    );
    
    if(!empty($new_user_data['user_email'])){
        if(email_exists($new_user_data['user_email'])){
            $user_id = email_exists($new_user_data['user_email']);
            if (!is_wp_error( $user_id ) ) {
                wp_set_current_user( $user_id );
                wp_set_auth_cookie( $user_id );
                echo 'ok';
                wp_die();
            }
        }else{
            $user_id = wp_insert_user($new_user_data);
            if (!is_wp_error( $user_id ) ) {
                wp_new_user_notification( $user_id, null, both ); 
                wp_set_current_user( $user_id );
                wp_set_auth_cookie( $user_id );
                echo 'ok';
                wp_die();
            }
        }
    }
}

/*
Add Scripts in admin side
*/

function admin_scripts()
{
	wp_enqueue_style( 'admin-css', plugin_dir_url(__FILE__) . 'css/admin.css', array());
	wp_enqueue_style( 'wp-color-picker');
	wp_enqueue_script( 'wp-color-picker-script-handle', plugins_url('js/wp-color-picker-script.js', __FILE__ ), array( 'wp-color-picker' ), false, true );
}
add_action( 'admin_enqueue_scripts', 'admin_scripts' );