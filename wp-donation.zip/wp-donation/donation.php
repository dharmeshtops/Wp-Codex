<?php
/*............Code By Tops 27 December for donation script...........*/
function Price_range_script_func() {
if(is_cart()){     
wp_enqueue_script( 'uiJS', get_stylesheet_directory_uri() . "/assets/jquery-ui.min.js", array(), '', false );
wp_enqueue_style("cssui", get_stylesheet_directory_uri() . "/assets/jquery-ui.css");
wp_enqueue_script( 'punchJS', get_stylesheet_directory_uri() . "/assets/jquery.ui.touch-punch.min.js", array(), '', false ); 
}
}    
add_action('wp_enqueue_scripts', 'Price_range_script_func');

/*..............Add Extra Fields To Woocomrce Cart................*/
add_action('woocommerce_cart_contents','ok_woocommerce_after_cart_table');
if ( ! function_exists( 'ok_woocommerce_after_cart_table' ) ){
    function ok_woocommerce_after_cart_table(){
        global $woocommerce;

        $gift_status_check = $woocommerce->session->gift_aid_status;
        if( $gift_status_check != '0' && $gift_status_check == 'yes'){
            $checked = 'checked';
        }

        if( !empty($_POST['ok_donation'])){
          $woocommerce->session->ok_donation = $_POST['ok_donation'];
          $amount = $woocommerce->session->ok_donation;
        }
        elseif(!empty($woocommerce->session->ok_donation)){
            $amount = $woocommerce->session->ok_donation;
        }
        else{
            $amount = 0;
        }
        if(!empty($woocommerce->session->twofive)){
               $five25 = '£'.$woocommerce->session->twofive;
        }
        else{
            $five25 = '£0.00';
        }
    ?>
<tr class="donation-block">
<td colspan="6">
    <div class="donation">
        <div class="donation_left">
            <h4>SUPPORT US</h4>
            <p>Help end suffering and bring hope to those struggling with their mental health by making Innate Health available to all. Please make your donation here.</p>
        </div>
        <div class="donation_right">
            <div class="donation_lbl"><p>Your Donation:</p></div>
            <div class="donation_pslider">
            <span class="currency-icon">£</span>
            <input type="text" name="ok_donation" class="input-text" id="ok_donation" value="<?php echo $amount;?>" />
            </div>
            <div id="storlekslider"></div> 
        </div>
    </div>
    <div class="area-basket-gift-aid">
        <h3>Gift Aid</h3>
        <p>Use Gift Aid and you can make your donation worth more. For every £1 you donate, we will be able to claim an extra 25p from the Inland Revenue. A £10 donation could be worth £12.50. Imagine what a difference that could make, and it doesn't cost you a thing.</p>
        <p>Your Gift Aid with this donation will amount to <em id="25p"><?php echo $five25; ?></em></p>
    </div>
    <div class="input-checkbox-section">
        <input type="checkbox" value="0" name="claim_gift_aid" class="claim_gift_aid" id="claim_gift_aid" <?php echo $checked; ?> >
        <label>I am a UK taxpayer - Please reclaim Gift Aid on my donations</label>
    </div>
</td>
</tr>
<?php   } }   


add_action( 'woocommerce_cart_calculate_fees','donation_add_fee_func' );
add_action('wp_footer','donation_fees_ajax_func');
function donation_add_fee_func() {
     global $woocommerce;
     $woocommerce->cart->add_fee( 'Donation',$woocommerce->session->ok_donation, true, 'standard' );
}

function donation_fees_ajax_func(){
    if(is_cart()){ 
global $woocommerce;    
 ?>
<script type="text/javascript">
jQuery(document).ready(function () {
    /*......Add gift Js...........*/
jQuery("#claim_gift_aid").click(function () {
        if (jQuery(this).is(":checked"))
        {
            claim_gift_aid = 'yes';
        }
        else{
            claim_gift_aid = 'no';
        }
        var data = {
            action: 'claim_gift_aid_action_priv',
            claim_gift_aid: claim_gift_aid,
                };
        jQuery.ajax({
            type: 'POST',
            url: '<?php echo admin_url('admin-ajax.php') ?>',
            data: data,
            dataType: 'json',
            success: function (res) {   
               console.log('Claim Gift status Trigger')
                }
        });
});     

jQuery( "#storlekslider" ).slider({
        range: "max",
        min: 0,
        max: 200,
        value: '<?php echo $woocommerce->session->ok_donation; ?>',
        slide: function( event, ui ) {
        jQuery( "#ok_donation" ).val( ui.value );
        jQuery(ui.value).val(jQuery('#ok_donation').val());
        var twofive = ui.value*0.25;
        jQuery("#25p").html('£'+twofive);
        },
        stop: function(event, ui) {
           var data = {
                donation_amount: ui.value,
                action: 'donation_amount_action_priv', 
                twofive: ui.value*0.25,
            };
            jQuery.ajax({
                type: 'POST',
                url: wc_cart_params.ajax_url,
                data: data,
                dataType: 'json',
                success: function (code) { 
                  jQuery(".actions input.button").click();
                }
            });
            }
        });
jQuery("#ok_donation").change(function() {
            var donation_amount = jQuery(this).val();
            var twofive = donation_amount*0.25;
            var upd_cart_btn = jQuery(".update-cart-button");
            var data = {
                donation_amount: donation_amount,
                action: 'donation_amount_action_priv',
                twofive: twofive,
            };
            jQuery.ajax({
                type: 'POST',
                url: wc_cart_params.ajax_url,
                data: data,
                dataType: 'html',
                success: function (code) {      
                  jQuery("#storlekslider").slider("value", donation_amount);    
                  jQuery("#25p").html('£'+twofive);
                  jQuery(".actions input.button").click(); 
                }
            });
}); 
jQuery("#ok_donation").keypress(function (e) { 
    if (e.which != 8 && e.which != 0 && (this.value.length == 0 && e.which == 48 || e.which > 57 )) {
        return false; 
    if(e.which  == 48){
        return false; 
    }          
    }
});
});
    </script>
<?php } }
 

add_action('wp_ajax_donation_amount_action_priv', 'donation_amount_action_priv_func');
add_action('wp_ajax_nopriv_donation_amount_action_priv', 'donation_amount_action_priv_func');

function donation_amount_action_priv_func(){    
     global $woocommerce;
     $amount = $_POST['donation_amount'];
     $twofive = $_POST['twofive'];
     $woocommerce->session->ok_donation = $amount;
     $woocommerce->session->twofive = $twofive;
}

/*.....Hook for gift aid status..........*/
add_action('wp_ajax_claim_gift_aid_action_priv', 'claim_gift_aid_action_priv_func');
add_action('wp_ajax_nopriv_claim_gift_aid_action_priv', 'claim_gift_aid_action_priv_func');
function claim_gift_aid_action_priv_func(){
     global $woocommerce;
     $gift_aid_status = $_POST['claim_gift_aid'];
     $woocommerce->session->gift_aid_status = $gift_aid_status;
}

/*.....Empty ok_donation From Session when Cart empty Hook action...... */
function empty_cart_ok_donation() {
     global $woocommerce;
    if ( WC()->cart->get_cart_contents_count() == 0 ) {
            $woocommerce->session->ok_donation = 0;
            $woocommerce->session->twofive = 0;
            $woocommerce->session->gift_aid_status = 0;
    }
}
add_action( 'woocommerce_check_cart_items', 'empty_cart_ok_donation' );

/*......Add _gift_aid_status Meta to Woocomerce Order.....*/
add_action( 'woocommerce_add_order_item_meta', 'so_add_order_item_meta', 10, 3 );
    function so_add_order_item_meta( $order_item_id, $cart_item, $cart_item_key ) {
        global $woocommerce;
        $status_gift = $woocommerce->session->gift_aid_status;
        if($status_gift == '0'){ $status_gift = 'no'; }
        wc_add_order_item_meta($order_item_id,'Git Aid Status',$status_gift);
        if($status_gift == 'yes'){
           wc_add_order_item_meta($order_item_id,'Gift Aid Amount','£'.$woocommerce->session->twofive);
        }
        $donation = $woocommerce->session->ok_donation;
        if(isset($donation) && !empty($donation) && $donation != 0){
          wc_add_order_item_meta($order_item_id,'Donation Fees','£'.$donation);
        }   
}



add_action('admin_head', 'display_meta_func');
function display_meta_func() {
  echo '<style>
    .display_meta th {
  width: auto !important;
} 
  </style>';
}