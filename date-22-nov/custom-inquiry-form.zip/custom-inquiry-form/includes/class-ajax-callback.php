<?php 
/**
* 
*/
class InquiryAjax 
{
	
	public function __construct()
	{
		add_action( 'wp_ajax_cb_submit_inquiry', array($this,'cb_submit_inquiry') );
		add_action( 'wp_ajax_nopriv_cb_submit_inquiry', array($this,'cb_submit_inquiry') );
	}
	public function cb_submit_inquiry(){
		$params = array();
    	parse_str($_POST['data'], $params);
    	$name = $params['name'];
    	$email = $params['email'];
    	$subject = $params['subject'];
    	$phone = $params['phone'];
    	$website = $params['website'];
    	$message = $params['message'];
    	global $wpdb;
		$table_name = $wpdb->prefix."custom_inquiry_az";
		$insert = $wpdb->insert($table_name, array(
		                'id' => '',
		                'name' => $name,
		                'email' => $email,
		                'subject' => $subject,
		                'phone' => $phone,
		                'website' => $website,
		                'message' => $message
		            )
		        );
		if($insert){
			echo json_encode(array('status'=>'true','message'=>'Inquiry submited successfully'));
		}else{
			echo json_encode(array('status'=>'false','message'=>'something went wrong while submitting!'));
		}
		exit();
	}
}

new InquiryAjax();